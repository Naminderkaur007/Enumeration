//Comment
//Group of same type of variable
//found nil value or empty value (its an Type safe)advantage

import UIKit

class EnumViewController: UIViewController {
    
    //Without Type
    enum player{
        
    case play
    case pause
    case stop
        
    }
     
    func withoutType(){
        
        var playerState = player.pause
        switch (playerState) {
        case .play:
            print("player is playing")
        case .pause:
            print("player is pause")
        case .stop:
            print("player is stop")
        default:
            print("default")
        }
    }
    
    //With Type
    enum playerAgain : String{
        
    case play = "Hi I am playing"
    case pause = "Hi I am pause"
    case stop = "Hi I am stop"
    
    }
    
    func withType(){
           
              let player = playerAgain.play
              print(player)
        
              let player1 = playerAgain.play.rawValue
              print(player1)
        
             
              
          }
    
    
    enum Beverage: CaseIterable {
        case coffee, tea, juice
    }
   
    //Enum with Function
    enum collegeFunc{
                    case studentName
                    case collegeName
                    case id
    
        
           func enumWithFunction() -> String{
               
               switch self{
               case .studentName:
                   return "My name is naminder kaur"
               case .collegeName:
                   return "Dwarka college"
               case .id:
                   return "3"
                
               }
      
        }
        
    }
    
    
    //with enum arguments
    enum Student{
        
        case studentName(String)
        case marks(String,String,String)
    }
    
    func withFunArguments(){
        
        let stuDetail = Student.studentName("Naminder")
        let stuMarks = Student.marks("75", "80", "90")
        switch stuMarks {
        case .studentName(let strName):
            print("my name is \(strName)")
        case .marks(let m1, let m2, let m3):
            print("my marks is \(m1) \(m2) \(m3)")
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      // withoutType()
      
     //   withType()
        
     //   let numberOfChoices = Beverage.allCases.count
    //    print("\(numberOfChoices) beverages available")
        // Prints "3 beverages available"
     
   //   let collFunDetail = collegeFunc.studentName.enumWithFunction()
     // print(collFunDetail)
    
      withFunArguments()
       

        }
    

    
}
